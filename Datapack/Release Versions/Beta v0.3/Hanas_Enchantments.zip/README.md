Adds new custom enchantments while keeping close to vanilla
